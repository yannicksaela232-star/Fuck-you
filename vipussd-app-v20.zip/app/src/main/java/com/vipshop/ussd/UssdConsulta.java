package com.vipshop.ussd;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;

/* Consulta de saldo de um SIM: *162# -> 8 -> 2. Fala o resultado e envia o texto ao bot. */
public class UssdConsulta {
    private final Context ctx;
    private final int slot;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final String[] plano = {"8", "2"};
    private int i = 0;
    private boolean fechado = false;

    UssdConsulta(Context ctx, int slot) {
        this.ctx = ctx;
        this.slot = slot;
    }

    void executar() {
        Voz.falar(ctx, "A consultar saldo do SIM " + (slot + 1) + ".");
        h.post(() -> enviar("*162#"));
        h.postDelayed(() -> fechar(null), 60000);
    }

    private void enviar(String texto) {
        try {
            TelephonyManager tm = Ussd.tm(ctx, slot);
            if (tm == null) { fechar(null); return; }
            tm.sendUssdRequest(texto, new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) {
                    if (i < plano.length) enviar(plano[i++]);
                    else fechar(resp == null ? "" : resp.toString());
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int falha) {
                    fechar(null);
                }
            }, h);
        } catch (Exception e) {
            fechar(null);
        }
    }

    private void fechar(String texto) {
        if (fechado) return;
        fechado = true;
        h.removeCallbacksAndMessages(null);
        int n = slot + 1;
        if (texto == null) {
            Voz.falar(ctx, "Nao consegui consultar o saldo do SIM " + n + ".");
            return;
        }
        Long mb = Saldo.extrair(texto);
        if (mb == null) {
            Voz.falar(ctx, "Nao consegui ler o saldo do SIM " + n + ".");
        } else {
            Voz.falar(ctx, "No SIM " + n + " temos " + Saldo.formatar(mb) + ".");
        }
        Bot.enviar(ctx, "/api/consulta", texto);
    }
}
