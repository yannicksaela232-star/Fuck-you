package com.vipshop.ussd;

import android.content.Context;

/* Função deste telefone: transferência (megas), pagamento (SMS) ou único (tudo). */
public class Papeis {
    static final String TRANSFERENCIA = "transferencia";
    static final String PAGAMENTO = "pagamento";
    static final String UNICO = "unico";

    static String papel(Context c) {
        return Config.p(c).getString("papel", UNICO);
    }

    static void definir(Context c, String papel) {
        Config.p(c).edit().putString("papel", papel).apply();
    }

    /* Índices dos separadores: 0 INÍCIO, 1 ENVIAR, 2 FILA, 3 LUCRO, 4 PAGAM., 5 GRUPOS, 6 SISTEMA */
    static boolean permite(Context c, int indice) {
        String p = papel(c);
        if (p.equals(TRANSFERENCIA)) return indice == 0 || indice == 1 || indice == 2 || indice == 6;
        if (p.equals(PAGAMENTO)) return indice == 4 || indice == 6;
        return true;
    }

    static int primeira(Context c) {
        return papel(c).equals(PAGAMENTO) ? 4 : 0;
    }

    static boolean podeTransferir(Context c) {
        return !papel(c).equals(PAGAMENTO);
    }

    static boolean podeReceberSms(Context c) {
        return !papel(c).equals(TRANSFERENCIA);
    }

    static String nome(Context c) {
        String p = papel(c);
        if (p.equals(TRANSFERENCIA)) return "Telefone de transferência";
        if (p.equals(PAGAMENTO)) return "Telefone de pagamento";
        return "Telefone único";
    }
}
